U0.L2 mystery runs. Unzip, then:
    mlflow ui --backend-store-uri sqlite:///mystery.db
Rules: curves and metrics only.
